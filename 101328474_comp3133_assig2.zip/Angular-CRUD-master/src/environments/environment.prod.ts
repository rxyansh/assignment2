export const environment = {
  production: true,
  firebaseconfig:{
    apiKey: "Give your API Key from Firebase",
    authDomain: "Give your",
    databaseURL: "Give your",
    projectId: "Give your ",
    storageBucket: "Give your ",
    messagingSenderId: "Give your"
  }
};
